import numpy as np
from random import shuffle

def softmax_loss_vectorized(W, X, y, reg):
  """
  Softmax loss function, vectorized version.
  Inputs:
  - W: C x D array of weights
  - X: D x N array of data. Data are D-dimensional columns
  - y: 1-dimensional array of length N with labels 0...K-1, for K classes
  - reg: (float) regularization strength
  Returns:
  a tuple of:
  - loss as single float
  - gradient with respect to weights W, an array of same size as W
  """
  # Initialize the loss and gradient to zero.
  loss = 0.0
  dW = np.zeros_like(W)

  #############################################################################
  # TODO: Compute the softmax loss and its gradient using no explicit loops.  #
  # Store the loss in loss and the gradient in dW. If you are not careful     #
  # here, it is easy to run into numeric instability. Don't forget the        #
  # regularization!                                                           #
  #############################################################################
  #pass
  #C = W.shape[0]
  #D = W.shape[1]
  N = X.shape[1]
  #print(N)
  #print(W.shape)
  #print(X.shape)
  z = W.dot(X)
  #print(z.shape)
  #print(W.shape)
  #print(X.shape)
  temp =np.matrix(np.max(z,axis=0))
  #print(temp.shape)
  #print(z.shape)
  z = z - temp
  #print(z.shape)
  sumj = np.sum(np.exp(z),axis=0)
  #print(sumj.shape)
  #loss = (-z[np.arange(N),y]+np.log(np.sum(np.exp(z),axis=1)))/N + reg*np.sum(W*W)
  #print(y.shape)
  #print(np.arange(N).shape)
  term1 = -z[y,np.arange(N)]
  #print(term1.shape)
  term2 = np.log(sumj)
  #print(term2.shape)
  loss = (term1+term2)
  loss = np.sum(loss)
  loss /= N
  loss += reg*np.sum(np.square(W))
  #print(loss.shape)
  #loss = loss.T
  #print(loss.shape)
  #loss = np.squeeze(loss)
  #print(loss.shape)
  #print(np.matrix(sumj).shape)
  #print(np.exp(z).shape)
  coef = np.exp(z)/np.matrix(sumj)
  coef[y,np.arange(N)] -= 1
  #print(coef.shape)
  dW = coef.dot(X.T)/N + reg*W

  #############################################################################
  #                          END OF YOUR CODE                                 #
  #############################################################################

  return loss, dW
